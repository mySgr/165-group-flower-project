<template>
    <div>
        <h5><span>&copy;</span>版权所有 165班 杀鸡小组</h5>
    </div>
</template>

<style scoped>
    div{
        margin-top: 30px;
        width: 100%;
        display: flex;
        justify-content: center;
        align-items: center;
        height: 70px;
        background-color: #999999;
    }
</style>